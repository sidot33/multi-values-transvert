import java.util.ArrayList;

public class test {
    public static void main(String[] args) {
        String a="['as d',we r,fgd']";
        ArrayList<String> k= exchangeto(a);
        System.out.print(k.size());

            System.out.print(k);

    }
    static ArrayList<String> exchangeto(String old) {
        int leng = old.length();
        ArrayList<String> res = new ArrayList<>();
        int k = -1;
        int j = -1;
        //old=old.substring(1,leng-1);
        for (int i = 0; i < leng; i++) {

            if (old.charAt(i) == ',') {
                k = i;
                res.add(old.substring(j+1, k));
            }

            j = k;
        }
        res.add(old.substring(k + 1));
        return res;
    }
}
