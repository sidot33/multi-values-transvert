import kotlin.jvm.Synchronized;

import java.sql.*;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
//需要导入jdbc的驱动包，官网有
//使用set内部顺序随机输出，不影响主键和多值的关系
//需要在mysql中另外建一个存放id和主键，一个存放id和多值的表，id自增
import static java.lang.Class.forName;

public class JDBCdemo {
    public static void main(String[] args) throws ClassNotFoundException, SQLException, InterruptedException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        //test 改为对应database名
        String url = "jdbc:mysql://localhost:3306/test?useUnicode=true&characterEncoding=utf8&useSSL=true";
        String username = "root";
        //自己改密码
        String password = "";
        Connection connection = DriverManager.getConnection(url, username, password);

        Statement statement = connection.createStatement();
        Statement statement2 = connection.createStatement();
        Statement statement3 = connection.createStatement();

//选择原数据库中data表中的多值和主键

        //connection.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
        String sql1 = "Select `tconst`,`characters` from `test.principal`";
        ResultSet resultset = statement.executeQuery(sql1);
        //上锁，避免重读
        connection.setAutoCommit(false);
        //Lock lock =new ReentrantLock();
int i=0;


        while (resultset.next()) {
            i++;

            if(i==10000){
            connection.commit();
                Thread.sleep(100);
                connection.setAutoCommit(false);

            i=0;}
            //获取多值，并用，区分，放入list
ArrayList<String> a=exchangeto((String)resultset.getObject("characters"));
//获取主键值
           String b=(String)resultset.getObject("tconst");
           //放入set查重
HashSet sto=new HashSet();
for(String j:a){

    if(!sto.contains(j)){
        sto.add(j);
    }
}
int num=sto.size();

//建立线程
            //connection.setAutoCommit(false);

            CountDownLatch latch=new CountDownLatch(num);
        for(Object k:sto) {
            new Thread(()->{
            //放入新的表主键，以及拆分后的多值

            String sqlgenere = "insert into `char`(`character`) values ('" + (String) k + "')";

            try {
                statement2.executeUpdate(sqlgenere);
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }

            String sqlnconst = "insert into `tconst` (`tconst`)values ('" + b + "')";
            try {
                statement3.executeUpdate(sqlnconst);
            } catch (SQLException throwables) {
                throwables.printStackTrace();

            }

                latch.countDown();
    }).start();}
            latch.await();
            //connection.commit();


        }
        connection.commit();
        resultset.close();
        statement.close();
        connection.close();

    }

//将多值输入到list中
    static ArrayList<String> exchangeto(String old) {
        int leng = old.length();
        ArrayList<String> res = new ArrayList<>();
        int k = -1;
        int j = -1;
       
        for (int i = 0; i < leng; i++) {

            if (old.charAt(i) == ',') {
                k = i;
                res.add(old.substring(j+1, k));
            }

            j = k;
        }
        res.add(old.substring(k + 1));
        return res;
    }
}
